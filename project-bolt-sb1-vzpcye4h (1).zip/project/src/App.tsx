import React, { useState, useEffect } from 'react';
import { Heart, Clock, Image as ImageIcon } from 'lucide-react';

function App() {
  const [photos, setPhotos] = useState<string[]>([]);
  const [message, setMessage] = useState('');
  const [startDate, setStartDate] = useState('');
  const [duration, setDuration] = useState({ days: 0, months: 0, years: 0 });

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotos(prev => [...prev, reader.result as string].slice(0, 3));
      };
      reader.readAsDataURL(file);
    }
  };

  useEffect(() => {
    if (startDate) {
      const timer = setInterval(() => {
        const start = new Date(startDate);
        const now = new Date();
        const diffTime = Math.abs(now.getTime() - start.getTime());
        const years = Math.floor(diffTime / (1000 * 60 * 60 * 24 * 365));
        const months = Math.floor((diffTime % (1000 * 60 * 60 * 24 * 365)) / (1000 * 60 * 60 * 24 * 30));
        const days = Math.floor((diffTime % (1000 * 60 * 60 * 24 * 30)) / (1000 * 60 * 60 * 24));
        setDuration({ days, months, years });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [startDate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 to-purple-100">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <Heart className="w-16 h-16 text-pink-500 mx-auto mb-4" />
            <h1 className="text-4xl font-bold text-gray-800 mb-2">Nossa História de Amor</h1>
            <p className="text-gray-600">Eternizando momentos especiais</p>
          </div>

          <div className="bg-white rounded-lg shadow-xl p-8 mb-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-6 flex items-center">
              <ImageIcon className="w-6 h-6 mr-2 text-pink-500" />
              Nossas Memórias
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              {[0, 1, 2].map((index) => (
                <div
                  key={index}
                  className="aspect-square relative bg-gray-100 rounded-lg overflow-hidden"
                >
                  {photos[index] ? (
                    <img
                      src={photos[index]}
                      alt={`Memória ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <label className="flex items-center justify-center w-full h-full cursor-pointer hover:bg-gray-200 transition-colors">
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handlePhotoUpload}
                      />
                      <div className="text-center">
                        <ImageIcon className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                        <span className="text-sm text-gray-500">Adicionar foto</span>
                      </div>
                    </label>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-xl p-8 mb-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-6 flex items-center">
              <Clock className="w-6 h-6 mr-2 text-pink-500" />
              Tempo Juntos
            </h2>
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Data de início do relacionamento
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-pink-500 focus:border-pink-500"
              />
            </div>
            {startDate && (
              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="bg-pink-50 p-4 rounded-lg">
                  <div className="text-3xl font-bold text-pink-600">{duration.years}</div>
                  <div className="text-sm text-gray-600">Anos</div>
                </div>
                <div className="bg-pink-50 p-4 rounded-lg">
                  <div className="text-3xl font-bold text-pink-600">{duration.months}</div>
                  <div className="text-sm text-gray-600">Meses</div>
                </div>
                <div className="bg-pink-50 p-4 rounded-lg">
                  <div className="text-3xl font-bold text-pink-600">{duration.days}</div>
                  <div className="text-sm text-gray-600">Dias</div>
                </div>
              </div>
            )}
          </div>

          <div className="bg-white rounded-lg shadow-xl p-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-6">Mensagem Especial</h2>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Escreva uma mensagem especial..."
              className="w-full h-32 px-4 py-2 border border-gray-300 rounded-md focus:ring-pink-500 focus:border-pink-500 resize-none"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;